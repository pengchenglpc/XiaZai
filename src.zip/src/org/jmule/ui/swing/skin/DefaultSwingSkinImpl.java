/*
 *  JMule - Java file sharing client
 *  Copyright (C) 2007-2008 JMule team ( jmule@jmule.org / http://jmule.org )
 *
 *  Any parts of this program derived from other projects, or contributed
 *  by third-party developers are copyrighted by their respective authors.
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package org.jmule.ui.swing.skin;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;

/**
 * 
 * @author javajox
 * @version $$Revision: 1.1 $$
 * Last changed by $$Author: javajox $$ on $$Date: 2008/07/31 16:44:20 $$
 */
public class DefaultSwingSkinImpl implements SwingSkin {
	
	private Font buttonFont = new Font("Dialog", 1, 14);
	private Font defaultFont = new Font("Dialog", 1, 14); 

	public Font getButtonFont() {
		
		return buttonFont;
	}

	public Image getButtonImage(int imageID) {

		return null;
	}

	public Color getDefaultColor() {

		return null;
	}

	public Font getDefaultFont() {
		
        return defaultFont;
	}

	public Font getLabelFont() {

		return null;
	}

	public Font getMenuBarFont() {

		return null;
	}

	public Font getMenuFont() {

		return null;
	}

	public Font getPopupMenuFont() {

		return null;
	}

}
