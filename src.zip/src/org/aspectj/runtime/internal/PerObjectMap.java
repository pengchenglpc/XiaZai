/* *******************************************************************
 * Copyright (c) 1999-2001 Xerox Corporation, 
 *               2002 Palo Alto Research Center, Incorporated (PARC).
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/epl-v10.html 
 *  
 * Contributors: 
 *     Xerox/PARC     initial implementation 
 * ******************************************************************/


package org.aspectj.runtime.internal;

//import java.util.WeakHashMap;  // XXX REQUIRES JAVA 2!!!!!!!!!!!!!!!!

public class PerObjectMap {
//    private WeakHashMap map = new WeakHashMap();
//
//    public boolean hasAspect(Object o) { return map.containsKey(o); }
//    
//    public Object aspectOf(Object o) {
//        return map.get(o);
//    }
//    
//    public void bind(Object object, Object _aspect) {
//        map.put(object, _aspect);
//    }
}
